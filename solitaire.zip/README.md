Solitairey is a JavaScript Solitaire collection using YUI 3.

Current games include:

- Agnes
- Flower Garden
- Forty Thieves
- Freecell
- Golf
- Grandfather's Clock
- Klondike
- Monte Carlo
- Pyramid
- Russian Solitaire
- Scorpion
- Spider (1, 2, and 4 Suit)
- Spiderette
- Tri Towers
- Will O' The Wisp
- Yukon
